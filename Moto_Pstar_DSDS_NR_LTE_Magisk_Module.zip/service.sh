#!/system/bin/sh
MODDIR=${0%/*}
sleep 20

# 开启高通 5G SA/NSA 支持
setprop persist.vendor.radio.5g_mode_pref 1
setprop persist.vendor.radio.nr_disable 0
setprop persist.vendor.radio.enable_dsds 1

DATA_SUB=$(cmd phone get-default-data-sub-id 2>/dev/null | tr -d '[:space:]')
if [ -z "$DATA_SUB" ] || [ "$DATA_SUB" = "null" ]; then
    DATA_SUB=1
fi

cmd phone set-allowed-network-types-for-reason $DATA_SUB 0 992850
settings put global preferred_network_mode$DATA_SUB 26

exit 0
