SKIPUNZIP=0
ui_print "**************************************"
ui_print "* Moto Edge 20 Pro NR/LTE Helper     *"
ui_print "* LineageOS 23.2 / Android 16        *"
ui_print "**************************************"
ui_print "- 正在配置 DSDS 5G 射频分配守护脚本..."
set_perm $MODPATH/service.sh 0 0 0755
ui_print "- 安装完成！重启生效。"
